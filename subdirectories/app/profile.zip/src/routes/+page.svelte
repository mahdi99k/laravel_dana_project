<script>
	import { goto } from '$app/navigation';
	import { onMount } from 'svelte';
	onMount(() => {
		goto('/inojob/private');
	});
</script>

<h1>درحال انتقال به بخش استخدامی هستید</h1>
