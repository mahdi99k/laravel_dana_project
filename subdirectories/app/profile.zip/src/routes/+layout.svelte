<script>
	import '@flaticon/flaticon-uicons/css/regular/rounded.css';
	import '../app.css';
</script>
<main>
	<slot />
</main>
<style>
	:root {
		background-color: #121212;
	}
	main {
		direction: rtl;
		background-color: #121212 !important;
	}
</style>
